/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ShiftDuty, 
  HolidaySetting,
  UserPermission 
} from '../types';
import { 
  Calendar, 
  Clock, 
  UserCheck, 
  PhoneCall, 
  Mail, 
  Slash, 
  Smartphone, 
  ToggleLeft, 
  ToggleRight, 
  Zap, 
  CheckCircle, 
  ShieldAlert, 
  Save, 
  CloudRain, 
  Sun,
  UserPlus 
} from 'lucide-react';

interface DutyProps {
  shifts: ShiftDuty[];
  holidays: HolidaySetting[];
  calendarMode: 'weekday' | 'holiday' | 'typhoon';
  onUpdateCalendarMode: (mode: 'weekday' | 'holiday' | 'typhoon') => Promise<void>;
  onUpdateShift: (date: string, field: 'primary' | 'secondary', payload: any) => void;
  users?: UserPermission[];
}

export function DutyManagementView({
  shifts,
  holidays,
  calendarMode,
  onUpdateCalendarMode,
  onUpdateShift,
  users = []
}: DutyProps) {
  
  // Shift Schedule modification state
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [primaryName, setPrimaryName] = useState('');
  const [primaryPhone, setPrimaryPhone] = useState('');
  const [primaryEmail, setPrimaryEmail] = useState('');
  const [secondaryName, setSecondaryName] = useState('');
  const [secondaryPhone, setSecondaryPhone] = useState('');
  const [secondaryEmail, setSecondaryEmail] = useState('');

  const [savingShiftIndex, setSavingShiftIndex] = useState<number | null>(null);

  // Trigger calendar mode updates
  const handleCalendarModeChange = async (mode: 'weekday' | 'holiday' | 'typhoon') => {
    try {
      await onUpdateCalendarMode(mode);
      alert('📅 行事曆模式已切換為：[' + (mode === 'weekday' ? '平日工作期' : mode === 'holiday' ? '假日/節慶' : '颱風警戒日') + ']！\n系統在「非工作交易時段」下，將自動啟用告警消音/靜音黑名單，避免派發不必要的結帳逾時通報。');
    } catch (err: any) {
      alert('行事曆設定變更失敗：' + err.message);
    }
  };

  const handleEditShiftClick = (idx: number, shift: ShiftDuty) => {
    setEditingIndex(idx);
    setPrimaryName(shift.primaryDuty.name);
    setPrimaryPhone(shift.primaryDuty.phone);
    setPrimaryEmail(shift.primaryDuty.email);
    setSecondaryName(shift.secondaryDuty.name);
    setSecondaryPhone(shift.secondaryDuty.phone);
    setSecondaryEmail(shift.secondaryDuty.email);
  };

  const handleSaveShiftChanges = (idx: number, date: string) => {
    setSavingShiftIndex(idx);
    
    // Dispatch local edits updates back
    onUpdateShift(date, 'primary', {
      name: primaryName,
      phone: primaryPhone,
      email: primaryEmail,
      lineVerified: shifts[idx].primaryDuty.lineVerified
    });

    onUpdateShift(date, 'secondary', {
      name: secondaryName,
      phone: secondaryPhone,
      email: secondaryEmail,
      lineVerified: shifts[idx].secondaryDuty.lineVerified
    });

    setSavingShiftIndex(null);
    setEditingIndex(null);
    alert('📅 日期 ' + date + ' 之值班調度與通知信箱存檔成功！已即時套用全台中繼推播名單。');
  };

  return (
    <div className="space-y-6">
      
      {/* 4.3 Calendar Time Control ( weekday/holiday/typhoon toggle ) */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div>
          <h2 className="text-sm font-bold text-white flex items-center">
            <Calendar className="w-5 h-5 text-indigo-400 mr-2" />
            4.3 行事曆智慧時段控管 (Calendar Controls)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            本行系統能智慧識別「例假日、平日、颱風警報停班假」。在非傳統交易/結帳時段，<b>系統會主動過濾並停止發送「結帳提醒」等不具備即時危害性之逾時警報</b>，避免錯誤騷擾休假或撤離中的員工。
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          <button
            onClick={() => handleCalendarModeChange('weekday')}
            className={`p-4 rounded-xl border transition text-center flex flex-col items-center justify-center cursor-pointer ${
              calendarMode === 'weekday' 
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow-lg glow-green' 
                : 'bg-slate-950/40 border-slate-850 text-slate-450 hover:bg-slate-800/25 hover:text-white'
            }`}
          >
            <Sun className={`w-8 h-8 mb-2 ${calendarMode === 'weekday' ? 'text-emerald-400 rotate-12' : 'text-slate-600'}`} />
            <span className="text-xs font-bold block">平日交易工作時段</span>
            <span className="text-[10px] mt-1.5 opacity-80 border-t border-slate-800 pt-1.5">
              啟動全管道即時警戒告警、隨時核算清算
            </span>
          </button>

          <button
            onClick={() => handleCalendarModeChange('holiday')}
            className={`p-4 rounded-xl border transition text-center flex flex-col items-center justify-center cursor-pointer ${
              calendarMode === 'holiday' 
                ? 'bg-indigo-550/20 border-indigo-500 text-indigo-300 shadow-lg' 
                : 'bg-slate-950/40 border-slate-850 text-slate-450 hover:bg-slate-800/25 hover:text-white'
            }`}
          >
            <Calendar className={`w-8 h-8 mb-2 ${calendarMode === 'holiday' ? 'text-indigo-400' : 'text-slate-600'}`} />
            <span className="text-xs font-bold block">週末法假日/民俗休市日</span>
            <span className="text-[10px] mt-1.5 opacity-80 border-t border-slate-800 pt-1.5 col-span-2">
              拒發非必要結帳逾時提醒，消音過濾
            </span>
          </button>

          <button
            onClick={() => handleCalendarModeChange('typhoon')}
            className={`p-4 rounded-xl border transition text-center flex flex-col items-center justify-center cursor-pointer ${
              calendarMode === 'typhoon' 
                ? 'bg-rose-500/20 border-rose-550 text-rose-350 shadow-lg glow-red' 
                : 'bg-slate-950/40 border-slate-850 text-slate-450 hover:bg-slate-800/25 hover:text-white'
            }`}
          >
            <CloudRain className={`w-8 h-8 mb-2 ${calendarMode === 'typhoon' ? 'text-rose-450 animate-bounce' : 'text-slate-600'}`} />
            <span className="text-xs font-bold block">防颱防汛緊急避災日</span>
            <span className="text-[10px] mt-1.5 opacity-80 border-t border-slate-800 pt-1.5">
              進入最高救災模式，封鎖全域結帳提示
            </span>
          </button>

        </div>

        <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-850 text-xs text-slate-400 leading-relaxed font-sans">
          <div className="flex items-center space-x-2 font-bold text-slate-300 mb-1">
            <ShieldAlert className="w-4 h-4 text-indigo-400" />
            <span>目前行事曆過濾狀態（情境展示）：</span>
          </div>
          {calendarMode === 'weekday' ? (
            <span className="text-emerald-400">🟢 系統目前處於【平日工作交易時段】，所有中台結算、AP指標大盤等皆處於靈敏偵測態。</span>
          ) : (
            <span className="text-amber-390">🟡 系統目前啟動了【智慧靜音機制】，在放假日，若在 15:30 觸發「本機餘額未拋逾時」警報，系統將靜音丟棄，確保同仁不被打擾。</span>
          )}
        </div>
      </div>

      {/* 4.1 Value shift management interface */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div>
          <h2 className="text-sm font-bold text-white flex items-center">
            <UserCheck className="w-5 h-5 text-indigo-400 mr-2" />
            4.1 & 4.2 全科人員值班排班設定與智能通知綁定
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            此處可維護每日、每班的值班第一、第二負責人。<b>智能通知邏輯已鎖定：告警推播簡訊/LINE僅在「當下當值時間」向有值班的人員手機派發，避免打擾休假群</b>。
          </p>
        </div>

        <div className="space-y-3">
          {shifts.map((s, idx) => {
            const isEditing = editingIndex === idx;
            
            // Check if this card represents "Today" (T_day is mock 2026-05-21)
            const isToday = s.date === '2026-05-21' || idx === 0;

            return (
              <div 
                key={s.date} 
                className={`p-4 rounded-xl border transition ${
                  isToday 
                    ? 'bg-slate-950/70 border-indigo-500/50 shadow-md ring-1 ring-indigo-505/20' 
                    : 'bg-slate-950/30 border-slate-850'
                }`}
              >
                <div className="flex flex-col lg:flex-row justify-between lg:items-center gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-white text-sm font-mono">{s.date} ({s.dayOfWeek})</span>
                      {isToday && (
                        <span className="px-1.5 py-0.2 bg-emerald-500/10 text-emerald-400 text-[10px] font-bold rounded-full border border-emerald-500/20">
                          值勤中 (ACTIVE)
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-450">全中台中樞業務清算、警報第一接收順位</p>
                  </div>

                  {/* Primary & Secondary View / Edit */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1 max-w-2xl text-xs font-mono">
                    
                    {/* Primary */}
                    <div className="bg-slate-900/40 p-3 rounded-lg border border-slate-850/60 text-slate-300">
                      <div className="text-sky-400 font-bold mb-1.5 flex items-center justify-between text-[11px]">
                        <span>第一負責人 (Primary)</span>
                        {s.primaryDuty.lineVerified ? (
                          <span className="text-[10px] text-emerald-400 font-normal">指紋授權 verified</span>
                        ) : (
                          <span className="text-[10px] text-slate-500 font-normal">待認證</span>
                        )}
                      </div>
                      
                      {isEditing ? (
                        <div className="space-y-1.5">
                          <label className="text-[9px] text-[#4dd0e1] block">選擇在職人員/自動帶出：</label>
                          <select
                            onChange={(e) => {
                              const found = users.find(u => u.id === e.target.value);
                              if (found) {
                                setPrimaryName(found.name);
                                setPrimaryPhone(found.phone);
                                setPrimaryEmail(found.email);
                              }
                            }}
                            className="w-full bg-slate-950 text-slate-200 py-1 px-1.5 rounded border border-slate-800 text-[10px]"
                            defaultValue=""
                          >
                            <option value="" disabled>-- 點此選擇帶出資訊 --</option>
                            {users.map(u => (
                              <option key={u.id} value={u.id}>{u.name} (門戶: {u.username})</option>
                            ))}
                          </select>
                          
                          <div className="space-y-1 pt-1 border-t border-slate-850/60">
                            <input 
                              type="text" value={primaryName} onChange={(e) => setPrimaryName(e.target.value)}
                              placeholder="任職名"
                              className="bg-slate-950 border border-slate-800 p-1 rounded text-xs w-full text-white"
                            />
                            <input 
                              type="text" value={primaryPhone} onChange={(e) => setPrimaryPhone(e.target.value)}
                              placeholder="電話"
                              className="bg-slate-950 border border-slate-800 p-1 rounded text-xs w-full text-slate-300 animate-fadeIn"
                            />
                            <input 
                              type="text" value={primaryEmail} onChange={(e) => setPrimaryEmail(e.target.value)}
                              placeholder="聯絡信箱"
                              className="bg-slate-950 border border-slate-800 p-1 rounded text-xs w-full text-slate-300 animate-fadeIn"
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-0.5 font-sans font-normal">
                          <div className="font-bold text-white text-sm">{s.primaryDuty.name}</div>
                          <div className="text-slate-400 flex items-center mt-1">
                            <PhoneCall className="w-3 h-3 text-slate-500 mr-1.5" />
                            {s.primaryDuty.phone}
                          </div>
                          <div className="text-slate-400 flex items-center mt-0.5">
                            <Mail className="w-3 h-3 text-slate-500 mr-1.5" />
                            {s.primaryDuty.email}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Secondary */}
                    <div className="bg-slate-900/40 p-3 rounded-lg border border-slate-850/60 text-slate-300">
                      <div className="text-slate-400 font-bold mb-1.5 flex items-center justify-between text-[11px]">
                        <span>第二負責人 (Backup)</span>
                      </div>
                      
                      {isEditing ? (
                        <div className="space-y-1.5">
                          <label className="text-[9px] text-[#4dd0e1] block">選擇在職人員/自動帶出：</label>
                          <select
                            onChange={(e) => {
                              const found = users.find(u => u.id === e.target.value);
                              if (found) {
                                setSecondaryName(found.name);
                                setSecondaryPhone(found.phone);
                                setSecondaryEmail(found.email);
                              }
                            }}
                            className="w-full bg-slate-950 text-slate-200 py-1 px-1.5 rounded border border-slate-800 text-[10px]"
                            defaultValue=""
                          >
                            <option value="" disabled>-- 點此選擇帶出資訊 --</option>
                            {users.map(u => (
                              <option key={u.id} value={u.id}>{u.name} (門戶: {u.username})</option>
                            ))}
                          </select>
                          
                          <div className="space-y-1 pt-1 border-t border-slate-850/60">
                            <input 
                              type="text" value={secondaryName} onChange={(e) => setSecondaryName(e.target.value)}
                              placeholder="任職名"
                              className="bg-slate-950 border border-slate-800 p-1 rounded text-xs w-full text-white"
                            />
                            <input 
                              type="text" value={secondaryPhone} onChange={(e) => setSecondaryPhone(e.target.value)}
                              placeholder="電話"
                              className="bg-slate-950 border border-slate-800 p-1 rounded text-xs w-full text-slate-300 animate-fadeIn"
                            />
                            <input 
                              type="text" value={secondaryEmail} onChange={(e) => setSecondaryEmail(e.target.value)}
                              placeholder="聯絡信箱"
                              className="bg-slate-950 border border-slate-800 p-1 rounded text-xs w-full text-slate-300 animate-fadeIn"
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-0.5 font-sans font-normal">
                          <div className="font-bold text-white text-sm">{s.secondaryDuty.name}</div>
                          <div className="text-slate-400 flex items-center mt-1">
                            <PhoneCall className="w-3 h-3 text-slate-500 mr-1.5" />
                            {s.secondaryDuty.phone}
                          </div>
                          <div className="text-slate-400 flex items-center mt-0.5">
                            <Mail className="w-3 h-3 text-slate-500 mr-1.5" />
                            {s.secondaryDuty.email}
                          </div>
                        </div>
                      )}
                    </div>

                  </div>

                  {/* Actions (Edit / Save) */}
                  <div className="flex items-center">
                    {isEditing ? (
                      <button
                        onClick={() => handleSaveShiftChanges(idx, s.date)}
                        className="bg-emerald-600 hover:bg-emerald-550 text-white font-bold text-xs py-1.5 px-3 rounded-lg cursor-pointer transition flex items-center space-x-1"
                      >
                        <Save className="w-4 h-4" />
                        <span>儲存</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => handleEditShiftClick(idx, s)}
                        className="bg-slate-805 hover:bg-slate-800 text-slate-400 hover:text-white font-bold text-xs py-1.5 px-3 rounded-lg cursor-pointer transition border border-slate-800"
                      >
                        編輯調整
                      </button>
                    )}
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
}
